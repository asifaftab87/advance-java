package org.loop;

public class LoopWhile3 {

	public static void main(String[] args) {
		
		int n = 10, i=1;
		while(i<=10) {
			System.out.println(n+" * "+i+" = "+n*i);
			i++;
		}
		//System.out.println("end");
	}
}
