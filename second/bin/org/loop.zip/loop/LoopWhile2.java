package org.loop;

public class LoopWhile2 {

	public static void main(String[] args) {
		
		int a = 1;
		while(a<=7) {
			a++;
			System.out.println("hello: "+a);
		}
		System.out.println("end");
	}
}
