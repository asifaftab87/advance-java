package org.loop;

public class LoopWhile1 {

	public static void main(String[] args) {
		
		int a = 10;
		while(a>=1) {
			System.out.println("hello: "+a);
			a--;
		}
	}
}
